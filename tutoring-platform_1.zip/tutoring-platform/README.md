# Tutoring Platform — Phase 0 Foundation

This is the starting skeleton for your platform, matching the planning
document (SRS, DB schema, roles). It's real, runnable code — not a mockup.

## What's included right now

- **Backend (Django + DRF):** custom User model with roles (Student, Teacher,
  Center Admin, Platform Admin), JWT authentication, teacher registration with
  document upload + admin approval workflow, a full Course API (create, edit,
  public browse/search with filters, teacher's own course list), and the full
  database schema from the planning doc modeled out (enrollments, homework,
  attendance, materials, announcements, messages, notifications, subscriptions,
  moderation) — all registered in the Django admin so you have a working
  system to test against immediately.
- **Frontend (React + Vite + Tailwind):** landing page, student registration,
  teacher registration (with file upload), login, a role-aware dashboard
  (teachers see and can create their own classes), a course creation form,
  and a public "Browse Classes" page with search/filters.

## What's NOT built yet (next phases, per the roadmap)

Enrollment request flow (the "Request to Enroll" button on Browse Classes is
a visible, clearly-disabled placeholder — not functional yet), homework
submission/grading UI, attendance marking UI, messaging UI, Center Admin
registration — the *data models* and *admin panel* support all of this
already, but the screens and API endpoints for these come in the next
phases. We're building this incrementally on purpose so you can understand
and test each piece.

---

## Running the Backend

You'll need Python 3.11+ installed.

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env            # then edit .env if needed (defaults work for local dev)

python manage.py makemigrations
python manage.py migrate

python manage.py createsuperuser   # create YOUR platform admin account

python manage.py runserver
```

The API will run at `http://localhost:8000`.
The Django admin panel (your Platform Admin dashboard for MVP) is at
`http://localhost:8000/admin/` — log in with the superuser you just created.

### Try it out
1. Go to `http://localhost:8000/admin/` and log in.
2. You'll see all the models: Users, Teacher Profiles, Organizations,
   Courses, Enrollments, Homework, etc. This is fully usable right now to
   manually test data even before the frontend screens exist for every
   feature.

---

## Running the Frontend

You'll need Node.js 18+ installed.

```bash
cd frontend
npm install
npm run dev
```

The site will run at `http://localhost:5173`. Make sure the backend is also
running (`http://localhost:8000`) since the frontend calls it directly.

### Try it out
1. Open `http://localhost:5173`
2. Click "I'm a Student" and register a test account.
3. Log in.
4. Click "I'm a Teacher" and register a test teacher account (upload any
   image as the "ID document" for testing).
5. Go back to the Django admin (`/admin/`) → Teacher Profiles → select your
   test teacher → use the "Approve selected teachers" action. This is exactly
   the verification workflow from the SRS.
6. Log in as your test teacher → go to Dashboard → click "+ Create Class" →
   fill out and submit the form.
7. Log out, visit `/courses` (or click "Browse Classes") without logging in —
   your new class should appear publicly, since the teacher is now approved.
   Try the search/subject/grade filters too.

---

## Project Structure

```
tutoring-platform/
├── backend/
│   ├── config/            # Django settings, URLs
│   └── apps/
│       ├── accounts/       # User model, roles, auth, teacher verification
│       ├── organizations/  # Educational centers
│       ├── subscriptions/  # Manual subscription management
│       ├── courses/        # Courses & sessions
│       ├── enrollments/    # Enrollment requests & 1-on-1 bookings
│       ├── attendance/     # Attendance records
│       ├── materials/      # Study materials
│       ├── homework/       # Homework & submissions
│       ├── communications/ # Announcements, messages, notifications
│       └── moderation/     # Reports & activity logs
└── frontend/
    └── src/
        ├── api/            # Axios client
        ├── context/        # Auth state
        ├── components/     # Navbar, etc.
        └── pages/          # Landing, Login, Register, Dashboard
```

## Next Steps (Phase 2 continued)

1. Run both servers and walk through the "Try it out" steps above to confirm
   everything works end to end on your machine.
2. Push this to a GitHub repo (`git init`, commit, push) — start the habit now.
3. Next feature to build: **Enrollment flow** — student requests to enroll
   in a course, teacher approves/rejects and marks payment status. Come back
   and ask for this whenever you're ready.

## A note on learning

Every file has comments explaining *why*, not just *what* — read through
`models.py` in each app alongside Section 5 (Database Planning) of your
planning document to connect the two. If anything doesn't make sense,
ask before moving forward — understanding this foundation matters more
than speed.
