import { Link } from 'react-router-dom'

export default function Landing() {
  return (
    <div className="max-w-4xl mx-auto text-center py-24 px-6">
      <h1 className="text-4xl font-bold text-gray-900 mb-4">
        Local Tutoring, Made Simple
      </h1>
      <p className="text-lg text-gray-600 mb-8">
        Connect with trusted private tutors, certified teachers, and educational
        centers across Egypt — manage classes, homework, and progress in one place.
      </p>
      <div className="space-x-4">
        <Link
          to="/register/student"
          className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-700"
        >
          I'm a Student
        </Link>
        <Link
          to="/register/teacher"
          className="bg-white border border-indigo-600 text-indigo-600 px-6 py-3 rounded-lg font-medium hover:bg-indigo-50"
        >
          I'm a Teacher
        </Link>
      </div>
    </div>
  )
}
