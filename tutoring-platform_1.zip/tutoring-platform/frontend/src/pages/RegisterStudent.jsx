import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import client from '../api/client'

export default function RegisterStudent() {
  const [form, setForm] = useState({ username: '', email: '', password: '', phone: '' })
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const navigate = useNavigate()

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    try {
      await client.post('/auth/register/student/', form)
      setSuccess(true)
      setTimeout(() => navigate('/login'), 1500)
    } catch (err) {
      setError('Registration failed. Check your details and try again.')
    }
  }

  return (
    <div className="max-w-md mx-auto mt-16 bg-white p-8 rounded-xl shadow-sm border border-gray-100">
      <h2 className="text-2xl font-bold mb-6">Student Sign Up</h2>
      {error && <p className="text-red-600 mb-4 text-sm">{error}</p>}
      {success && <p className="text-green-600 mb-4 text-sm">Account created! Redirecting to login...</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="username" placeholder="Username" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />
        <input name="email" type="email" placeholder="Email" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />
        <input name="phone" placeholder="Phone Number" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
        <input name="password" type="password" placeholder="Password" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />
        <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg font-medium hover:bg-indigo-700">
          Create Account
        </button>
      </form>
      <p className="text-sm text-gray-500 mt-4">
        Are you a teacher? <Link to="/register/teacher" className="text-indigo-600">Register here</Link>
      </p>
    </div>
  )
}
