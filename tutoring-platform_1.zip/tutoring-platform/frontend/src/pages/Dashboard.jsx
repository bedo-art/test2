import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import client from '../api/client'

export default function Dashboard() {
  const { user } = useAuth()

  if (!user) return null

  return (
    <div className="max-w-4xl mx-auto mt-12 px-6">
      <h1 className="text-2xl font-bold mb-2">Welcome, {user.username} 👋</h1>
      <p className="text-gray-500 mb-8">
        Logged in as: <span className="font-medium capitalize">{user.role.replace('_', ' ')}</span>
      </p>

      {user.role === 'student' && <StudentDashboard />}
      {user.role === 'teacher' && <TeacherDashboard />}
      {user.role === 'center_admin' && <CenterAdminDashboard />}
      {user.role === 'platform_admin' && <PlatformAdminDashboard />}
    </div>
  )
}

// Each of these is a placeholder — this is where Phase 2+ features
// (courses, enrollments, homework, etc.) will be built out.

function StudentDashboard() {
  return (
    <Card title="My Courses">
      You haven't enrolled in any courses yet. Browse available teachers to get started.
    </Card>
  )
}

function TeacherDashboard() {
  const [courses, setCourses] = useState(null)

  useEffect(() => {
    client.get('/courses/mine/').then((res) => setCourses(res.data)).catch(() => setCourses([]))
  }, [])

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">My Classes</h2>
        <Link
          to="/courses/new"
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700"
        >
          + Create Class
        </Link>
      </div>

      {courses === null && <p className="text-gray-400 text-sm">Loading...</p>}

      {courses !== null && courses.length === 0 && (
        <p className="text-gray-500 text-sm">
          You haven't created any classes yet. Click "+ Create Class" to get started.
          Note: your classes won't be publicly visible until your account is approved
          by the platform admin.
        </p>
      )}

      <ul className="space-y-3">
        {courses?.map((c) => (
          <li key={c.id} className="border border-gray-100 rounded-lg p-4 flex justify-between items-center">
            <div>
              <p className="font-medium">{c.title}</p>
              <p className="text-sm text-gray-500">
                {c.subject} · {c.grade_level} · <span className="capitalize">{c.status}</span>
              </p>
            </div>
            <span className="text-sm text-gray-400">
              {c.available_seats !== null ? `${c.available_seats} seats left` : 'Unlimited seats'}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function CenterAdminDashboard() {
  return (
    <Card title="Organization Overview">
      Manage your teachers, view center-wide classes, and monitor students here.
    </Card>
  )
}

function PlatformAdminDashboard() {
  return (
    <Card title="Platform Admin">
      Use the full Django admin panel at <code className="bg-gray-100 px-1 rounded">/admin/</code> to
      approve teachers, manage subscriptions, and moderate content.
    </Card>
  )
}

function Card({ title, children }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <h2 className="text-lg font-semibold mb-2">{title}</h2>
      <p className="text-gray-500 text-sm">{children}</p>
    </div>
  )
}
