import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import client from '../api/client'

export default function RegisterTeacher() {
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    phone: '',
    bio: '',
    subjects: '',
    grade_levels: '',
    experience_years: '',
    national_id_number: '',
  })
  const [idDocument, setIdDocument] = useState(null)
  const [credentialDocument, setCredentialDocument] = useState(null)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const navigate = useNavigate()

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')

    // Files require multipart/form-data, so we build a FormData object
    // instead of sending plain JSON.
    const data = new FormData()
    Object.entries(form).forEach(([key, value]) => data.append(key, value))
    if (idDocument) data.append('id_document', idDocument)
    if (credentialDocument) data.append('credential_document', credentialDocument)

    try {
      await client.post('/auth/register/teacher/', data, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      setSuccess(true)
      setTimeout(() => navigate('/login'), 2000)
    } catch (err) {
      setError('Registration failed. Check your details and try again.')
    }
  }

  return (
    <div className="max-w-lg mx-auto mt-16 bg-white p-8 rounded-xl shadow-sm border border-gray-100">
      <h2 className="text-2xl font-bold mb-2">Teacher Sign Up</h2>
      <p className="text-sm text-gray-500 mb-6">
        Your account will be reviewed by our team before it becomes visible to students.
        This usually takes 1-2 business days.
      </p>
      {error && <p className="text-red-600 mb-4 text-sm">{error}</p>}
      {success && (
        <p className="text-green-600 mb-4 text-sm">
          Account created! We'll review your documents shortly. Redirecting to login...
        </p>
      )}
      <form onSubmit={handleSubmit} className="space-y-4" encType="multipart/form-data">
        <input name="username" placeholder="Username" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />
        <input name="email" type="email" placeholder="Email" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />
        <input name="phone" placeholder="Phone Number" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />
        <input name="password" type="password" placeholder="Password" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />

        <hr className="my-2" />

        <textarea name="bio" placeholder="Short bio" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" rows={3} />
        <input name="subjects" placeholder="Subjects you teach (comma separated)" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
        <input name="grade_levels" placeholder="Grade levels (comma separated)" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
        <input name="experience_years" type="number" placeholder="Years of experience" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
        <input name="national_id_number" placeholder="National ID Number" onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" required />

        <div>
          <label className="block text-sm text-gray-600 mb-1">ID Document (photo/scan)</label>
          <input type="file" onChange={(e) => setIdDocument(e.target.files[0])} className="w-full text-sm" required />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Teaching credentials (optional)</label>
          <input type="file" onChange={(e) => setCredentialDocument(e.target.files[0])} className="w-full text-sm" />
        </div>

        <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg font-medium hover:bg-indigo-700">
          Submit for Review
        </button>
      </form>
      <p className="text-sm text-gray-500 mt-4">
        Are you a student? <Link to="/register/student" className="text-indigo-600">Register here</Link>
      </p>
    </div>
  )
}
