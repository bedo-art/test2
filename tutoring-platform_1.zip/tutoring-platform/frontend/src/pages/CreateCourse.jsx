import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import client from '../api/client'

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

export default function CreateCourse() {
  const [form, setForm] = useState({
    title: '',
    subject: '',
    grade_level: '',
    description: '',
    course_type: 'recurring',
    price: '',
    max_capacity: '',
    start_time: '',
    end_time: '',
    term_start: '',
    term_end: '',
  })
  const [selectedDays, setSelectedDays] = useState([])
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const navigate = useNavigate()

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  function toggleDay(day) {
    setSelectedDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    )
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')

    const payload = {
      ...form,
      schedule_days: selectedDays.join(','),
      price: form.price || null,
      max_capacity: form.max_capacity || null,
      term_start: form.term_start || null,
      term_end: form.term_end || null,
      start_time: form.start_time || null,
      end_time: form.end_time || null,
    }

    try {
      await client.post('/courses/', payload)
      setSuccess(true)
      setTimeout(() => navigate('/dashboard'), 1200)
    } catch (err) {
      setError(
        err.response?.data
          ? JSON.stringify(err.response.data)
          : 'Something went wrong creating the course.'
      )
    }
  }

  return (
    <div className="max-w-2xl mx-auto mt-12 mb-16 bg-white p-8 rounded-xl shadow-sm border border-gray-100">
      <h1 className="text-2xl font-bold mb-1">Create a Class</h1>
      <p className="text-sm text-gray-500 mb-6">
        Students will find this once it's published and your account is approved.
      </p>

      {error && <p className="text-red-600 mb-4 text-sm break-words">{error}</p>}
      {success && <p className="text-green-600 mb-4 text-sm">Class created! Redirecting...</p>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          name="title" placeholder="Class title (e.g. Grade 10 Chemistry - Term 1)"
          value={form.title} onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg px-4 py-2" required
        />

        <div className="grid grid-cols-2 gap-4">
          <input
            name="subject" placeholder="Subject (e.g. Chemistry)"
            value={form.subject} onChange={handleChange}
            className="border border-gray-300 rounded-lg px-4 py-2" required
          />
          <input
            name="grade_level" placeholder="Grade level (e.g. Secondary 2)"
            value={form.grade_level} onChange={handleChange}
            className="border border-gray-300 rounded-lg px-4 py-2" required
          />
        </div>

        <textarea
          name="description" placeholder="Description for students"
          value={form.description} onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg px-4 py-2" rows={3}
        />

        <div>
          <label className="block text-sm text-gray-600 mb-2">Class type</label>
          <select
            name="course_type" value={form.course_type} onChange={handleChange}
            className="w-full border border-gray-300 rounded-lg px-4 py-2"
          >
            <option value="recurring">Recurring weekly class</option>
            <option value="one_on_one">One-on-one</option>
          </select>
        </div>

        {form.course_type === 'recurring' && (
          <div>
            <label className="block text-sm text-gray-600 mb-2">Class days</label>
            <div className="flex flex-wrap gap-2">
              {DAYS.map((day) => (
                <button
                  type="button"
                  key={day}
                  onClick={() => toggleDay(day)}
                  className={`px-3 py-1 rounded-full text-sm border ${
                    selectedDays.includes(day)
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white text-gray-600 border-gray-300'
                  }`}
                >
                  {day.slice(0, 3)}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Start time</label>
            <input type="time" name="start_time" value={form.start_time} onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">End time</label>
            <input type="time" name="end_time" value={form.end_time} onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Term start</label>
            <input type="date" name="term_start" value={form.term_start} onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Term end</label>
            <input type="date" name="term_end" value={form.term_end} onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Price (EGP, optional)</label>
            <input type="number" name="price" value={form.price} onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Max students (optional)</label>
            <input type="number" name="max_capacity" value={form.max_capacity} onChange={handleChange} className="w-full border border-gray-300 rounded-lg px-4 py-2" />
          </div>
        </div>

        <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg font-medium hover:bg-indigo-700">
          Create Class
        </button>
      </form>
    </div>
  )
}
