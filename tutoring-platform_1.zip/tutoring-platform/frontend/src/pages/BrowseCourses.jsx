import { useEffect, useState } from 'react'
import client from '../api/client'

export default function BrowseCourses() {
  const [courses, setCourses] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({ subject: '', grade_level: '', search: '' })

  useEffect(() => {
    fetchCourses()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function fetchCourses(e) {
    if (e) e.preventDefault()
    setLoading(true)
    const params = {}
    if (filters.subject) params.subject = filters.subject
    if (filters.grade_level) params.grade_level = filters.grade_level
    if (filters.search) params.search = filters.search

    try {
      const res = await client.get('/courses/', { params })
      setCourses(res.data)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-5xl mx-auto mt-10 mb-16 px-6">
      <h1 className="text-2xl font-bold mb-6">Browse Classes</h1>

      <form onSubmit={fetchCourses} className="flex flex-wrap gap-3 mb-8">
        <input
          placeholder="Search by title or teacher"
          value={filters.search}
          onChange={(e) => setFilters({ ...filters, search: e.target.value })}
          className="border border-gray-300 rounded-lg px-4 py-2 flex-1 min-w-[200px]"
        />
        <input
          placeholder="Subject"
          value={filters.subject}
          onChange={(e) => setFilters({ ...filters, subject: e.target.value })}
          className="border border-gray-300 rounded-lg px-4 py-2 w-40"
        />
        <input
          placeholder="Grade level"
          value={filters.grade_level}
          onChange={(e) => setFilters({ ...filters, grade_level: e.target.value })}
          className="border border-gray-300 rounded-lg px-4 py-2 w-40"
        />
        <button type="submit" className="bg-indigo-600 text-white px-5 py-2 rounded-lg hover:bg-indigo-700">
          Search
        </button>
      </form>

      {loading && <p className="text-gray-500">Loading classes...</p>}

      {!loading && courses.length === 0 && (
        <p className="text-gray-500">
          No classes found yet. Once teachers are approved and publish classes, they'll show up here.
        </p>
      )}

      <div className="grid gap-4 sm:grid-cols-2">
        {courses.map((course) => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>
    </div>
  )
}

function CourseCard({ course }) {
  return (
    <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
      <div className="flex justify-between items-start mb-2">
        <h2 className="font-semibold text-gray-900">{course.title}</h2>
        {course.teacher_is_verified && (
          <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Verified</span>
        )}
      </div>
      <p className="text-sm text-gray-500 mb-1">
        {course.subject} · {course.grade_level}
      </p>
      <p className="text-sm text-gray-500 mb-1">
        Teacher: {course.teacher_name}
        {course.organization_name ? ` (${course.organization_name})` : ''}
      </p>
      {course.schedule_days && (
        <p className="text-sm text-gray-500 mb-1">
          {course.schedule_days} · {course.start_time?.slice(0, 5)}–{course.end_time?.slice(0, 5)}
        </p>
      )}
      <p className="text-sm text-gray-500 mb-3">
        {course.price ? `${course.price} EGP` : 'Price on request'}
        {course.available_seats !== null && ` · ${course.available_seats} seats left`}
      </p>
      <p className="text-sm text-gray-600 line-clamp-2">{course.description}</p>
      <button
        disabled
        title="Enrollment requests are coming in the next feature build"
        className="mt-4 w-full bg-gray-100 text-gray-400 py-2 rounded-lg text-sm font-medium cursor-not-allowed"
      >
        Request to Enroll (coming soon)
      </button>
    </div>
  )
}
