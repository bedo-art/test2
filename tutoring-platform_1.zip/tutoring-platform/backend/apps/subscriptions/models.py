from django.db import models
from django.conf import settings


class Subscription(models.Model):
    """
    MVP: manually managed by the Platform Admin based on offline payment proof
    (Instapay/Vodafone Cash/Fawry/bank transfer). Designed so a future
    `gateway_transaction_id` field can be added without breaking anything.
    """

    class OwnerType(models.TextChoices):
        TEACHER = 'teacher', 'Independent Teacher'
        ORGANIZATION = 'organization', 'Organization'

    class Status(models.TextChoices):
        TRIAL = 'trial', 'Trial'
        ACTIVE = 'active', 'Active'
        EXPIRED = 'expired', 'Expired'
        CANCELLED = 'cancelled', 'Cancelled'

    owner_type = models.CharField(max_length=20, choices=OwnerType.choices)
    teacher = models.OneToOneField(
        'accounts.TeacherProfile', on_delete=models.CASCADE,
        null=True, blank=True, related_name='subscription'
    )
    organization = models.OneToOneField(
        'organizations.Organization', on_delete=models.CASCADE,
        null=True, blank=True, related_name='subscription'
    )

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.TRIAL)
    trial_end_date = models.DateField(null=True, blank=True)
    current_period_end = models.DateField(null=True, blank=True)

    payment_proof = models.FileField(upload_to='payment_proofs/', blank=True, null=True)
    activated_by_admin = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='subscriptions_activated'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        owner = self.teacher or self.organization
        return f"Subscription({owner}) - {self.status}"
