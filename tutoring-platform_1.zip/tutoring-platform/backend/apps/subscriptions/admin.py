from django.contrib import admin
from .models import Subscription


@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    """This is where you activate/extend/cancel subscriptions after reviewing payment proof."""
    list_display = ('__str__', 'owner_type', 'status', 'current_period_end')
    list_filter = ('owner_type', 'status')
    actions = ['activate_subscriptions', 'expire_subscriptions']

    @admin.action(description='Mark selected subscriptions as Active')
    def activate_subscriptions(self, request, queryset):
        queryset.update(status=Subscription.Status.ACTIVE, activated_by_admin=request.user)

    @admin.action(description='Mark selected subscriptions as Expired')
    def expire_subscriptions(self, request, queryset):
        queryset.update(status=Subscription.Status.EXPIRED)
