from django.contrib import admin
from .models import Report, ActivityLog


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ('id', 'reported_by', 'entity_type', 'status', 'created_at')
    list_filter = ('entity_type', 'status')


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ('actor', 'action', 'entity_type', 'timestamp')
    readonly_fields = [f.name for f in ActivityLog._meta.fields]

    def has_add_permission(self, request):
        return False  # logs are created by the system, not manually
