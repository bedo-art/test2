from django.contrib import admin
from .models import Enrollment, Booking


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student', 'course', 'status', 'payment_status', 'requested_at')
    list_filter = ('status', 'payment_status')
    search_fields = ('student__username', 'course__title')


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('student', 'teacher', 'requested_datetime', 'status')
    list_filter = ('status',)
