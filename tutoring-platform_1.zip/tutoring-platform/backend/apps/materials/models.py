from django.db import models
from django.conf import settings


class Material(models.Model):
    course = models.ForeignKey('courses.Course', on_delete=models.CASCADE, related_name='materials')
    uploaded_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to='course_materials/', blank=True, null=True)
    external_video_link = models.URLField(blank=True, help_text="YouTube/Google Drive link (MVP has no native video hosting)")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.course.title})"
