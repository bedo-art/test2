from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, TeacherProfile


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'role', 'status', 'is_staff')
    list_filter = ('role', 'status')
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Platform Info', {'fields': ('role', 'phone', 'status', 'language_preference')}),
    )


@admin.register(TeacherProfile)
class TeacherProfileAdmin(admin.ModelAdmin):
    """
    This is where you, the Platform Admin, will approve/reject teachers.
    Select one or more pending teachers and use the actions below.
    """
    list_display = ('user', 'organization', 'verification_status', 'is_publicly_listed', 'created_at')
    list_filter = ('verification_status', 'is_publicly_listed')
    search_fields = ('user__username', 'user__email', 'national_id_number')
    actions = ['approve_teachers', 'reject_teachers']

    @admin.action(description='Approve selected teachers (makes them publicly listed)')
    def approve_teachers(self, request, queryset):
        updated = queryset.update(
            verification_status=TeacherProfile.VerificationStatus.APPROVED,
            is_publicly_listed=True,
        )
        self.message_user(request, f"{updated} teacher(s) approved and publicly listed.")

    @admin.action(description='Reject selected teachers')
    def reject_teachers(self, request, queryset):
        updated = queryset.update(
            verification_status=TeacherProfile.VerificationStatus.REJECTED,
            is_publicly_listed=False,
        )
        self.message_user(request, f"{updated} teacher(s) rejected.")
