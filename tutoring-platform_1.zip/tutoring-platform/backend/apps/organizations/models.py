from django.db import models
from django.conf import settings


class Organization(models.Model):
    """An educational center/academy — owns one subscription, has many teachers."""
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    owner = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='owned_organization'
    )
    max_teacher_slots = models.PositiveIntegerField(default=5)
    city = models.CharField(max_length=100, blank=True)  # optional display info
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
