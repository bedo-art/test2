from rest_framework import permissions


class IsTeacherUser(permissions.BasePermission):
    """Only users with role=teacher (and an approved TeacherProfile) can create courses."""

    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True  # anyone can view/list (filtered separately in the view)
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role == 'teacher'
            and hasattr(request.user, 'teacher_profile')
        )


class IsCourseOwner(permissions.BasePermission):
    """Only the teacher who owns a course can edit/delete it."""

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.teacher.user_id == request.user.id
