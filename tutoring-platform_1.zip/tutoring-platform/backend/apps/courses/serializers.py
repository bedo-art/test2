from rest_framework import serializers
from .models import Course, Session


class SessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Session
        fields = ['id', 'scheduled_date', 'start_time', 'end_time', 'meeting_link', 'status']


class CourseListSerializer(serializers.ModelSerializer):
    """Used for the public browse/search page — only shows what students need to decide."""
    teacher_name = serializers.CharField(source='teacher.user.username', read_only=True)
    teacher_is_verified = serializers.BooleanField(source='teacher.is_publicly_listed', read_only=True)
    organization_name = serializers.CharField(source='teacher.organization.name', read_only=True, default=None)
    available_seats = serializers.SerializerMethodField()

    class Meta:
        model = Course
        fields = [
            'id', 'title', 'subject', 'grade_level', 'description', 'course_type',
            'price', 'max_capacity', 'available_seats', 'schedule_days',
            'start_time', 'end_time', 'status',
            'teacher_name', 'teacher_is_verified', 'organization_name',
        ]

    def get_available_seats(self, obj):
        if obj.max_capacity is None:
            return None  # unlimited
        approved_count = obj.enrollments.filter(status='approved').count()
        return max(obj.max_capacity - approved_count, 0)


class CourseDetailSerializer(CourseListSerializer):
    """Adds sessions for the course detail page."""
    sessions = SessionSerializer(many=True, read_only=True)

    class Meta(CourseListSerializer.Meta):
        fields = CourseListSerializer.Meta.fields + ['sessions', 'term_start', 'term_end']


class CourseCreateUpdateSerializer(serializers.ModelSerializer):
    """Used by teachers to create/edit their own courses. `teacher` is set automatically."""

    class Meta:
        model = Course
        fields = [
            'id', 'title', 'subject', 'grade_level', 'description', 'course_type',
            'price', 'max_capacity', 'schedule_days', 'start_time', 'end_time',
            'term_start', 'term_end', 'status',
        ]

    def create(self, validated_data):
        teacher_profile = self.context['request'].user.teacher_profile
        return Course.objects.create(teacher=teacher_profile, **validated_data)
