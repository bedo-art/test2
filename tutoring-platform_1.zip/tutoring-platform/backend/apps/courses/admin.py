from django.contrib import admin
from .models import Course, Session


class SessionInline(admin.TabularInline):
    model = Session
    extra = 0


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'teacher', 'subject', 'grade_level', 'course_type', 'status')
    list_filter = ('course_type', 'status', 'subject', 'grade_level')
    search_fields = ('title', 'teacher__user__username')
    inlines = [SessionInline]


@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ('course', 'scheduled_date', 'start_time', 'status')
    list_filter = ('status',)
