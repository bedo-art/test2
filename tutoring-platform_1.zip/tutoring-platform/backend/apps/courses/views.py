from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Q

from .models import Course
from .serializers import CourseListSerializer, CourseDetailSerializer, CourseCreateUpdateSerializer
from .permissions import IsTeacherUser, IsCourseOwner


class CourseViewSet(viewsets.ModelViewSet):
    """
    GET  /api/courses/            -> public browse/search (open courses, approved teachers only)
    GET  /api/courses/?mine=true  -> the logged-in teacher's own courses (any status)
    GET  /api/courses/{id}/       -> course detail
    POST /api/courses/            -> create a course (teacher only)
    PUT/PATCH /api/courses/{id}/  -> edit own course
    DELETE /api/courses/{id}/     -> delete own course
    """
    permission_classes = [IsTeacherUser, IsCourseOwner]

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.AllowAny()]
        return super().get_permissions()

    def get_serializer_class(self):
        if self.action == 'list':
            return CourseListSerializer
        if self.action == 'retrieve':
            return CourseDetailSerializer
        return CourseCreateUpdateSerializer

    def get_queryset(self):
        qs = Course.objects.select_related('teacher__user', 'teacher__organization')

        # A teacher viewing their own dashboard sees everything they own,
        # regardless of status (draft/closed/archived included).
        if self.request.query_params.get('mine') == 'true' and self.request.user.is_authenticated:
            return qs.filter(teacher__user=self.request.user).order_by('-created_at')

        # Everyone else (students, public visitors) only sees courses that
        # are open for enrollment AND belong to an admin-approved teacher.
        qs = qs.filter(status='open', teacher__is_publicly_listed=True)

        params = self.request.query_params
        if subject := params.get('subject'):
            qs = qs.filter(subject__icontains=subject)
        if grade_level := params.get('grade_level'):
            qs = qs.filter(grade_level__icontains=grade_level)
        if course_type := params.get('course_type'):
            qs = qs.filter(course_type=course_type)
        if params.get('verified_only') == 'true':
            qs = qs.filter(teacher__verification_status='approved')
        if search := params.get('search'):
            qs = qs.filter(
                Q(title__icontains=search) | Q(teacher__user__username__icontains=search)
            )

        return qs.order_by('-created_at')

    @action(detail=False, methods=['get'], permission_classes=[permissions.IsAuthenticated])
    def mine(self, request):
        """Convenience endpoint: GET /api/courses/mine/ — same as ?mine=true but explicit."""
        courses = Course.objects.filter(teacher__user=request.user).order_by('-created_at')
        serializer = CourseListSerializer(courses, many=True)
        return Response(serializer.data)
